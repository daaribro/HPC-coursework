#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <crypt.h>
#include <time.h>

/******************************************************************************
  Demonstrates how to crack an encrypted password using a simple
  "brute force" algorithm. Works on passwords that consist only of 2 uppercase
  letters and a 2 digit integer. Your personalised data set is included in the
  code. 

  Compile with:
    cc -o CrackAAZ99 CrackAAZ99.c -lcrypt

  If you want to analyse the results then use the redirection operator to send
  output to a file that you can view using an editor or the less utility:

    ./CrackAAZ99 | grep -a Time | awk '{print $4}' | sed 's/ns//'

  Dr Kevan Buckley, University of Wolverhampton, 2018
******************************************************************************/
int n_passwords = 4;

char *encrypted_passwords[] = {
  "$6$KB$oQM8lJ03nHtqxHFpCToSFsUrWl/oYyh9q2Y.8ZaG5JSa23k0E.Myi6nCwJPYub.H.QRZmaTl2AhQ526ePQWuP/",
  "$6$KB$E0Yf4vu65R4MeZ.Pf6romN8Qz9C7XzqbHN/CssxmvEqlpSnwri8Fv8iCLX3QQYnXxOSlJyrQaHUfFk1iWtVWo.",
  "$6$KB$O8rx4s2UvO4zxFd1ZWLik0QPXmtlYnQ.zOjHh2yu8T9QaJKF6tWv2bNmjjhttkP6lE.yxZoEHtN3JKjE4sevC.",
  "$6$KB$.UcnUy0gE9PZFcNU.49ByRTw35nDfdCQgYFMvvrZF3Kwkj2GH54Qaz/bCabNvQ97uAYAQ.BLBPH2KSmn2aBq31"
};

/**
 Required by lack of standard function in C.   
*/

void substr(char *dest, char *src, int start, int length){
  memcpy(dest, src + start, length);
  *(dest + length) = '\0';
}

/**
 This function can crack the kind of password explained above. All combinations
 that are tried are displayed and when the password is found, #, is put at the 
 start of the line. Note that one of the most time consuming operations that 
 it performs is the output of intermediate results, so performance experiments 
 for this kind of program should not include this. i.e. comment out the printfs.
*/

void crack(char *salt_and_encrypted){ 
  int a, b, c, d;     // Loop counters
  char salt[7];    // String used in hashing the password. Need space for \0
  char plain[7];   // The combination of letters currently being checked
  char *enc;       // Pointer to the encrypted password
  int count = 0;   // The number of combinations explored so far

  substr(salt, salt_and_encrypted, 0, 6);

 for(a='A'; a<='Z'; a++){
  for(b='A'; b<='Z'; b++){
    for(c='A'; c<='Z'; c++){
      for(d=0; d<=99; d++){
        sprintf(plain, "%c%c%c%02d", a, b, c, d); 
        enc = (char *) crypt(plain, salt);
        count++;
        if(strcmp(salt_and_encrypted, enc) == 0){
          printf("#%-8d%s %s\n", count, plain, enc);
        } else {
          printf(" %-8d%s %s\n", count, plain, enc);
        }
      }
    }
  }
}
  printf("%d solutions explored\n", count);
}

int time_difference(struct timespec *start, struct timespec *finish, 
                              long long int *difference) {
  long long int ds =  finish->tv_sec - start->tv_sec; 
  long long int dn =  finish->tv_nsec - start->tv_nsec; 

     if(dn < 0 ) {
        ds--;
        dn += 1000000000; 
     } 
  *difference = ds * 1000000000 + dn;
  return !(*difference > 0);
}

int main(int argc, char *argv[]) {
  int i;
  struct timespec start, finish;   
  long long int time_elapsed;

  clock_gettime(CLOCK_MONOTONIC, &start);

  for(i = 0; i<n_passwords; i<i++){
	crack(encrypted_passwords[i]);
  }
 
  clock_gettime(CLOCK_MONOTONIC, &finish);
  time_difference(&start, &finish, &time_elapsed);
  printf("Time elapsed was %lldns or %0.9lfs\n", time_elapsed, 
         (time_elapsed/1.0e9)); 
   return 0;
}



